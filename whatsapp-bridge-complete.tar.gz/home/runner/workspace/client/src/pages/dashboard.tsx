import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import MetricsCard from "@/components/dashboard/metrics-card";
import SubmissionsTable from "@/components/dashboard/submissions-table";
import SystemStatus from "@/components/dashboard/system-status";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, CheckCircle, AlertTriangle, Clock } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { FormSubmission, MessageTemplate } from "@shared/schema";

export default function Dashboard() {
  const { toast } = useToast();

  const { data: metrics, isLoading: metricsLoading } = useQuery<{
    todaySubmissions: number;
    messagesSent: number;
    failedMessages: number;
    avgProcessingTime: string;
  }>({
    queryKey: ["/api/dashboard/metrics"],
  });

  const { data: recentSubmissions, isLoading: submissionsLoading } = useQuery<FormSubmission[]>({
    queryKey: ["/api/submissions/recent"],
  });

  const { data: systemStatus, isLoading: statusLoading } = useQuery<{
    hubspotWebhook: string;
    whatsappApi: string;
    rateLimits: string;
    messageQueue: string;
  }>({
    queryKey: ["/api/status"],
  });

  const { data: activeTemplate } = useQuery<MessageTemplate[]>({
    queryKey: ["/api/templates"],
    select: (templates) => templates?.find((t) => t.isActive),
  });

  const handleTestConnection = async () => {
    try {
      const response = await apiRequest("POST", "/api/test/whatsapp");
      const result = await response.json();
      toast({
        title: "Test Successful",
        description: result.message,
      });
    } catch (error: any) {
      toast({
        title: "Test Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleSendTestMessage = async () => {
    try {
      const response = await apiRequest("POST", "/api/test/whatsapp");
      const result = await response.json();
      toast({
        title: "Test Message Sent",
        description: result.message,
      });
    } catch (error: any) {
      toast({
        title: "Failed to Send Test Message",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <>
      <Header
        title="Dashboard"
        subtitle="Monitor your HubSpot form submissions and WhatsApp message delivery"
        actions={
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
              <span className="text-sm text-slate-600">WhatsApp Connected</span>
            </div>
            <Button onClick={handleTestConnection} className="bg-blue-600 hover:bg-blue-700">
              <Clock className="w-4 h-4 mr-2" />
              Test Connection
            </Button>
          </div>
        }
      />

      <div className="flex-1 overflow-auto p-6">
        {/* Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <MetricsCard
            title="Today's Submissions"
            value={metricsLoading ? "..." : metrics?.todaySubmissions || 0}
            icon={FileText}
            trend="+12%"
            trendLabel="vs yesterday"
            bgColor="bg-blue-50"
            iconColor="text-blue-600"
            loading={metricsLoading}
          />
          <MetricsCard
            title="Messages Sent"
            value={metricsLoading ? "..." : metrics?.messagesSent || 0}
            icon={CheckCircle}
            trend="91.7%"
            trendLabel="success rate"
            bgColor="bg-emerald-50"
            iconColor="text-emerald-600"
            loading={metricsLoading}
          />
          <MetricsCard
            title="Failed Messages"
            value={metricsLoading ? "..." : metrics?.failedMessages || 0}
            icon={AlertTriangle}
            trend="8.3%"
            trendLabel="of total"
            bgColor="bg-red-50"
            iconColor="text-red-600"
            loading={metricsLoading}
          />
          <MetricsCard
            title="Processing Time"
            value={metricsLoading ? "..." : metrics?.avgProcessingTime || "0s"}
            icon={Clock}
            trend="-200ms"
            trendLabel="vs avg"
            bgColor="bg-amber-50"
            iconColor="text-amber-600"
            loading={metricsLoading}
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Recent Activity */}
          <div className="lg:col-span-2">
            <SubmissionsTable
              submissions={recentSubmissions || []}
              loading={submissionsLoading}
            />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <SystemStatus status={systemStatus} loading={statusLoading} />

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  className="w-full bg-blue-600 hover:bg-blue-700" 
                  onClick={handleSendTestMessage}
                >
                  Send Test Message
                </Button>
                <Button variant="outline" className="w-full">
                  Refresh Webhook
                </Button>
                <Button variant="outline" className="w-full">
                  View Logs
                </Button>
              </CardContent>
            </Card>

            {/* Template Preview */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle>Active Template</CardTitle>
                <Button variant="ghost" size="sm" className="text-blue-600 hover:text-blue-700">
                  Edit
                </Button>
              </CardHeader>
              <CardContent>
                <div className="bg-slate-50 rounded-lg p-4">
                  <p className="text-sm text-slate-600 italic">
                    {activeTemplate?.content || "No active template found"}
                  </p>
                </div>
                <div className="mt-3 text-xs text-slate-500">
                  Last updated: {activeTemplate?.updatedAt ? new Date(activeTemplate.updatedAt).toLocaleDateString() : "Never"}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </>
  );
}
