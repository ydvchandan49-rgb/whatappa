import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import StatusBadge from "@/components/ui/status-badge";
import { WhatsappMessage } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

export default function MessageHistory() {
  const { data: messages, isLoading } = useQuery<WhatsappMessage[]>({
    queryKey: ["/api/messages"],
  });

  return (
    <>
      <Header
        title="Message History"
        subtitle="View all WhatsApp messages sent through the system"
      />

      <div className="flex-1 overflow-auto p-6">
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Phone Number</TableHead>
                    <TableHead>Message Content</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Sent At</TableHead>
                    <TableHead>Error</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    Array.from({ length: 5 }).map((_, i) => (
                      <TableRow key={i}>
                        <TableCell><Skeleton className="w-24 h-4" /></TableCell>
                        <TableCell><Skeleton className="w-40 h-4" /></TableCell>
                        <TableCell><Skeleton className="w-16 h-6 rounded-full" /></TableCell>
                        <TableCell><Skeleton className="w-16 h-4" /></TableCell>
                        <TableCell><Skeleton className="w-20 h-4" /></TableCell>
                      </TableRow>
                    ))
                  ) : messages?.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-8 text-slate-500">
                        No messages found
                      </TableCell>
                    </TableRow>
                  ) : (
                    messages?.map((message) => (
                      <TableRow key={message.id}>
                        <TableCell className="text-sm text-slate-900">
                          {message.phoneNumber}
                        </TableCell>
                        <TableCell className="text-sm text-slate-900 max-w-xs truncate">
                          {message.messageContent}
                        </TableCell>
                        <TableCell>
                          <StatusBadge status={message.status} />
                        </TableCell>
                        <TableCell className="text-sm text-slate-500">
                          {message.sentAt ? new Date(message.sentAt).toLocaleString() : '-'}
                        </TableCell>
                        <TableCell className="text-sm text-red-600 max-w-xs truncate">
                          {message.errorMessage || '-'}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
