import { useQuery, useMutation } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import Header from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { SystemConfig } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Copy, Save } from "lucide-react";

export default function Configuration() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    whatsappApiEndpoint: "",
    whatsappAccessToken: "",
    whatsappPhoneNumberId: "",
    hubspotWebhookSecret: "",
    enableLogging: true,
  });

  const { data: config, isLoading } = useQuery<SystemConfig>({
    queryKey: ["/api/config"],
  });

  const updateMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/config", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/config"] });
      toast({ title: "Configuration saved successfully" });
    },
    onError: (error: any) => {
      toast({ title: "Failed to save configuration", description: error.message, variant: "destructive" });
    },
  });

  useEffect(() => {
    if (config) {
      setFormData({
        whatsappApiEndpoint: config.whatsappApiEndpoint || "https://graph.facebook.com/v17.0",
        whatsappAccessToken: config.whatsappAccessToken === "***" ? "" : config.whatsappAccessToken || "",
        whatsappPhoneNumberId: config.whatsappPhoneNumberId || "",
        hubspotWebhookSecret: config.hubspotWebhookSecret || "",
        enableLogging: config.enableLogging ?? true,
      });
    }
  }, [config]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateMutation.mutate(formData);
  };

  const copyWebhookUrl = () => {
    const webhookUrl = `${window.location.origin}/api/webhook/hubspot`;
    navigator.clipboard.writeText(webhookUrl).then(() => {
      toast({ title: "Webhook URL copied to clipboard" });
    });
  };

  const webhookUrl = `${window.location.origin}/api/webhook/hubspot`;

  return (
    <>
      <Header
        title="Configuration"
        subtitle="Configure WhatsApp Business API and HubSpot webhook settings"
      />

      <div className="flex-1 overflow-auto p-6">
        <div className="max-w-2xl mx-auto">
          <form onSubmit={handleSubmit} className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>WhatsApp Business API</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="whatsappApiEndpoint">API Endpoint</Label>
                  <Input
                    id="whatsappApiEndpoint"
                    type="url"
                    value={formData.whatsappApiEndpoint}
                    onChange={(e) => setFormData({ ...formData, whatsappApiEndpoint: e.target.value })}
                    placeholder="https://graph.facebook.com/v17.0"
                  />
                </div>
                <div>
                  <Label htmlFor="whatsappAccessToken">Access Token</Label>
                  <Input
                    id="whatsappAccessToken"
                    type="password"
                    value={formData.whatsappAccessToken}
                    onChange={(e) => setFormData({ ...formData, whatsappAccessToken: e.target.value })}
                    placeholder="Enter your WhatsApp Business API token"
                  />
                  <p className="text-xs text-slate-500 mt-1">
                    Your token will be encrypted and stored securely
                  </p>
                </div>
                <div>
                  <Label htmlFor="whatsappPhoneNumberId">Phone Number ID</Label>
                  <Input
                    id="whatsappPhoneNumberId"
                    value={formData.whatsappPhoneNumberId}
                    onChange={(e) => setFormData({ ...formData, whatsappPhoneNumberId: e.target.value })}
                    placeholder="Enter your phone number ID"
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>HubSpot Integration</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="webhookUrl">Webhook URL</Label>
                  <div className="flex">
                    <Input
                      id="webhookUrl"
                      value={webhookUrl}
                      readOnly
                      className="bg-slate-50"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      className="ml-2"
                      onClick={copyWebhookUrl}
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Use this URL in your HubSpot webhook configuration
                  </p>
                </div>
                <div>
                  <Label htmlFor="hubspotWebhookSecret">Webhook Secret (Optional)</Label>
                  <Input
                    id="hubspotWebhookSecret"
                    type="password"
                    value={formData.hubspotWebhookSecret}
                    onChange={(e) => setFormData({ ...formData, hubspotWebhookSecret: e.target.value })}
                    placeholder="Enter webhook secret for verification"
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>System Settings</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="enableLogging"
                    checked={formData.enableLogging}
                    onCheckedChange={(checked) => setFormData({ ...formData, enableLogging: checked })}
                  />
                  <Label htmlFor="enableLogging">Enable detailed logging</Label>
                </div>
              </CardContent>
            </Card>

            <div className="flex justify-end">
              <Button type="submit" disabled={updateMutation.isPending || isLoading}>
                <Save className="w-4 h-4 mr-2" />
                Save Configuration
              </Button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
}
