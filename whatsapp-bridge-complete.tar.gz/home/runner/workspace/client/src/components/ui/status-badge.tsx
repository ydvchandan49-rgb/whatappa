import { Badge } from "@/components/ui/badge";
import { Check, Clock, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface StatusBadgeProps {
  status: string;
  className?: string;
}

export default function StatusBadge({ status, className }: StatusBadgeProps) {
  const getStatusConfig = (status: string) => {
    switch (status.toLowerCase()) {
      case "sent":
      case "delivered":
        return {
          variant: "default" as const,
          className: "bg-emerald-100 text-emerald-800 hover:bg-emerald-100",
          icon: Check,
        };
      case "pending":
        return {
          variant: "secondary" as const,
          className: "bg-amber-100 text-amber-800 hover:bg-amber-100",
          icon: Clock,
        };
      case "failed":
        return {
          variant: "destructive" as const,
          className: "bg-red-100 text-red-800 hover:bg-red-100",
          icon: X,
        };
      default:
        return {
          variant: "outline" as const,
          className: "bg-slate-100 text-slate-800 hover:bg-slate-100",
          icon: Clock,
        };
    }
  };

  const config = getStatusConfig(status);
  const Icon = config.icon;

  return (
    <Badge 
      variant={config.variant} 
      className={cn("inline-flex items-center gap-1", config.className, className)}
    >
      <Icon className="w-3 h-3" />
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </Badge>
  );
}