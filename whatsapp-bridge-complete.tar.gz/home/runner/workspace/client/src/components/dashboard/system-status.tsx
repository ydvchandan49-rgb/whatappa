import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

interface SystemStatusProps {
  status?: {
    hubspotWebhook: string;
    whatsappApi: string;
    rateLimits: string;
    messageQueue: string;
  };
  loading?: boolean;
}

export default function SystemStatus({ status, loading = false }: SystemStatusProps) {
  const getStatusColor = (statusValue: string) => {
    if (statusValue.includes("active") || statusValue.includes("connected") || statusValue.includes("clear")) {
      return "bg-emerald-500";
    }
    if (statusValue.includes("disconnected") || statusValue.includes("failed")) {
      return "bg-red-500";
    }
    return "bg-amber-500";
  };

  const getStatusLabel = (statusValue: string) => {
    if (statusValue.includes("active")) return "Active";
    if (statusValue.includes("connected")) return "Connected";
    if (statusValue.includes("clear")) return "Clear";
    if (statusValue.includes("disconnected")) return "Disconnected";
    return statusValue;
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>System Status</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Skeleton className="w-2 h-2 rounded-full" />
                <Skeleton className="w-24 h-4" />
              </div>
              <Skeleton className="w-16 h-4" />
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  const statusItems = [
    { label: "HubSpot Webhook", value: status?.hubspotWebhook || "unknown" },
    { label: "WhatsApp API", value: status?.whatsappApi || "unknown" },
    { label: "Rate Limits", value: status?.rateLimits || "unknown" },
    { label: "Message Queue", value: status?.messageQueue || "unknown" },
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle>System Status</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {statusItems.map((item) => (
          <div key={item.label} className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className={`w-2 h-2 ${getStatusColor(item.value)} rounded-full`}></div>
              <span className="text-sm text-slate-600">{item.label}</span>
            </div>
            <span className="text-xs font-medium text-slate-900">
              {getStatusLabel(item.value)}
            </span>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}