import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import type { LucideIcon } from "lucide-react";

interface MetricsCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  trend?: string;
  trendLabel?: string;
  bgColor: string;
  iconColor: string;
  loading?: boolean;
}

export default function MetricsCard({
  title,
  value,
  icon: Icon,
  trend,
  trendLabel,
  bgColor,
  iconColor,
  loading = false,
}: MetricsCardProps) {
  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="space-y-2">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-8 w-16" />
            </div>
            <Skeleton className="w-12 h-12 rounded-lg" />
          </div>
          <div className="flex items-center mt-4 space-x-2">
            <Skeleton className="h-4 w-12" />
            <Skeleton className="h-4 w-20" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-600">{title}</p>
            <p className="text-3xl font-semibold text-slate-900 mt-1">{value}</p>
          </div>
          <div className={`w-12 h-12 ${bgColor} rounded-lg flex items-center justify-center`}>
            <Icon className={`${iconColor} text-xl`} />
          </div>
        </div>
        {trend && trendLabel && (
          <div className="flex items-center mt-4 text-sm">
            <span className="text-emerald-600 font-medium">{trend}</span>
            <span className="text-slate-500 ml-1">{trendLabel}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}