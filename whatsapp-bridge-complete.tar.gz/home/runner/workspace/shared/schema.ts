import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const formSubmissions = pgTable("form_submissions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  hubspotSubmissionId: text("hubspot_submission_id").notNull().unique(),
  contactName: text("contact_name").notNull(),
  contactEmail: text("contact_email").notNull(),
  contactPhone: text("contact_phone").notNull(),
  formName: text("form_name").notNull(),
  formData: jsonb("form_data").notNull(),
  status: text("status").notNull().default("pending"), // pending, sent, failed
  createdAt: timestamp("created_at").defaultNow().notNull(),
  processedAt: timestamp("processed_at"),
});

export const whatsappMessages = pgTable("whatsapp_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  submissionId: varchar("submission_id").references(() => formSubmissions.id).notNull(),
  phoneNumber: text("phone_number").notNull(),
  messageContent: text("message_content").notNull(),
  templateId: varchar("template_id"),
  status: text("status").notNull().default("pending"), // pending, sent, delivered, failed
  whatsappMessageId: text("whatsapp_message_id"),
  errorMessage: text("error_message"),
  sentAt: timestamp("sent_at"),
  deliveredAt: timestamp("delivered_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const messageTemplates = pgTable("message_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  content: text("content").notNull(),
  isActive: boolean("is_active").default(false).notNull(),
  variables: jsonb("variables").notNull().default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const systemConfig = pgTable("system_config", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  whatsappApiEndpoint: text("whatsapp_api_endpoint"),
  whatsappAccessToken: text("whatsapp_access_token"),
  whatsappPhoneNumberId: text("whatsapp_phone_number_id"),
  hubspotWebhookSecret: text("hubspot_webhook_secret"),
  enableLogging: boolean("enable_logging").default(true).notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertFormSubmissionSchema = createInsertSchema(formSubmissions).omit({
  id: true,
  createdAt: true,
  processedAt: true,
});

export const insertMessageSchema = createInsertSchema(whatsappMessages).omit({
  id: true,
  createdAt: true,
  sentAt: true,
  deliveredAt: true,
});

export const insertTemplateSchema = createInsertSchema(messageTemplates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertConfigSchema = createInsertSchema(systemConfig).omit({
  id: true,
  updatedAt: true,
});

export type FormSubmission = typeof formSubmissions.$inferSelect;
export type InsertFormSubmission = z.infer<typeof insertFormSubmissionSchema>;
export type WhatsappMessage = typeof whatsappMessages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type MessageTemplate = typeof messageTemplates.$inferSelect;
export type InsertTemplate = z.infer<typeof insertTemplateSchema>;
export type SystemConfig = typeof systemConfig.$inferSelect;
export type InsertConfig = z.infer<typeof insertConfigSchema>;
