import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertFormSubmissionSchema, insertConfigSchema, insertTemplateSchema } from "@shared/schema";
import { z } from "zod";

// WhatsApp API service
class WhatsAppService {
  private async sendMessage(phoneNumber: string, message: string, config: any): Promise<{ success: boolean; messageId?: string; error?: string }> {
    try {
      if (!config?.whatsappAccessToken || !config?.whatsappPhoneNumberId) {
        throw new Error("WhatsApp configuration missing");
      }

      const endpoint = config.whatsappApiEndpoint || "https://graph.facebook.com/v17.0";
      const url = `${endpoint}/${config.whatsappPhoneNumberId}/messages`;

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${config.whatsappAccessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messaging_product: "whatsapp",
          to: phoneNumber.replace(/\D/g, ''), // Remove non-digits
          type: "text",
          text: { body: message }
        })
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.error?.message || 'WhatsApp API error');
      }

      return {
        success: true,
        messageId: result.messages?.[0]?.id
      };
    } catch (error: any) {
      return {
        success: false,
        error: error.message
      };
    }
  }

  async processFormSubmission(submissionId: string): Promise<void> {
    const submission = await storage.getFormSubmission(submissionId);
    if (!submission) return;

    const template = await storage.getActiveTemplate();
    if (!template) {
      await storage.updateFormSubmissionStatus(submissionId, "failed");
      return;
    }

    const config = await storage.getConfig();
    
    // Replace template variables
    let messageContent = template.content;
    messageContent = messageContent.replace(/\{\{contactName\}\}/g, submission.contactName);
    messageContent = messageContent.replace(/\{\{formName\}\}/g, submission.formName);
    messageContent = messageContent.replace(/\{\{contactEmail\}\}/g, submission.contactEmail);

    // Create message record
    const message = await storage.createMessage({
      submissionId: submission.id,
      phoneNumber: submission.contactPhone,
      messageContent,
      templateId: template.id,
      status: "pending"
    });

    // Send WhatsApp message
    const result = await this.sendMessage(submission.contactPhone, messageContent, config);
    
    if (result.success) {
      await storage.updateMessageStatus(message.id, "sent", result.messageId);
      await storage.updateFormSubmissionStatus(submissionId, "sent");
    } else {
      await storage.updateMessageStatus(message.id, "failed", undefined, result.error);
      await storage.updateFormSubmissionStatus(submissionId, "failed");
    }
  }
}

const whatsappService = new WhatsAppService();

export async function registerRoutes(app: Express): Promise<Server> {
  // Dashboard metrics
  app.get("/api/dashboard/metrics", async (req, res) => {
    try {
      const metrics = await storage.getDashboardMetrics();
      res.json(metrics);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Recent form submissions
  app.get("/api/submissions/recent", async (req, res) => {
    try {
      const submissions = await storage.getRecentFormSubmissions(10);
      res.json(submissions);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // All form submissions
  app.get("/api/submissions", async (req, res) => {
    try {
      const submissions = await storage.getRecentFormSubmissions(100);
      res.json(submissions);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // HubSpot webhook endpoint
  app.post("/api/webhook/hubspot", async (req, res) => {
    try {
      const payload = req.body;
      
      if (!payload || !Array.isArray(payload)) {
        return res.status(400).json({ message: "Invalid payload" });
      }

      for (const event of payload) {
        if (event.eventType === "contact.form-submission") {
          const properties = event.properties || {};
          
          // Extract contact information
          const submissionData = {
            hubspotSubmissionId: event.objectId || event.subscriptionId,
            contactName: properties.firstname || properties.name || "Unknown",
            contactEmail: properties.email || "",
            contactPhone: properties.phone || properties.mobilephone || "",
            formName: properties.hs_form_name || "Contact Form",
            formData: properties,
            status: "pending"
          };

          // Validate required fields
          if (!submissionData.contactPhone || !submissionData.contactEmail) {
            console.log("Skipping submission - missing phone or email");
            continue;
          }

          // Check if we already processed this submission
          const existing = await storage.getFormSubmissionByHubspotId(submissionData.hubspotSubmissionId);
          if (existing) {
            console.log("Submission already processed:", submissionData.hubspotSubmissionId);
            continue;
          }

          // Create submission record
          const submission = await storage.createFormSubmission(submissionData);
          
          // Process WhatsApp message asynchronously
          whatsappService.processFormSubmission(submission.id).catch(console.error);
        }
      }

      res.status(200).json({ message: "Webhook processed" });
    } catch (error: any) {
      console.error("Webhook error:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // Test WhatsApp connection
  app.post("/api/test/whatsapp", async (req, res) => {
    try {
      const config = await storage.getConfig();
      if (!config?.whatsappAccessToken || !config?.whatsappPhoneNumberId) {
        return res.status(400).json({ message: "WhatsApp configuration not found" });
      }

      // Send test message to a test number (you should configure this)
      const testPhone = process.env.TEST_PHONE_NUMBER || config.whatsappPhoneNumberId;
      const result = await whatsappService['sendMessage'](testPhone, "This is a test message from WhatsApp Bridge", config);
      
      if (result.success) {
        res.json({ message: "Test message sent successfully", messageId: result.messageId });
      } else {
        res.status(400).json({ message: result.error });
      }
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Message history
  app.get("/api/messages", async (req, res) => {
    try {
      const messages = await storage.getRecentMessages(100);
      res.json(messages);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Message templates
  app.get("/api/templates", async (req, res) => {
    try {
      const templates = await storage.getAllTemplates();
      res.json(templates);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/templates", async (req, res) => {
    try {
      const templateData = insertTemplateSchema.parse(req.body);
      const template = await storage.createTemplate(templateData);
      res.status(201).json(template);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation error", errors: error.errors });
      } else {
        res.status(500).json({ message: error.message });
      }
    }
  });

  app.put("/api/templates/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = insertTemplateSchema.partial().parse(req.body);
      const template = await storage.updateTemplate(id, updates);
      
      if (!template) {
        return res.status(404).json({ message: "Template not found" });
      }
      
      res.json(template);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation error", errors: error.errors });
      } else {
        res.status(500).json({ message: error.message });
      }
    }
  });

  app.delete("/api/templates/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteTemplate(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Template not found" });
      }
      
      res.status(204).send();
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // System configuration
  app.get("/api/config", async (req, res) => {
    try {
      const config = await storage.getConfig();
      if (!config) {
        return res.json({
          whatsappApiEndpoint: "",
          whatsappAccessToken: "",
          whatsappPhoneNumberId: "",
          hubspotWebhookSecret: "",
          enableLogging: true
        });
      }
      
      // Don't expose sensitive data
      res.json({
        ...config,
        whatsappAccessToken: config.whatsappAccessToken ? "***" : ""
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/config", async (req, res) => {
    try {
      const configData = insertConfigSchema.parse(req.body);
      const config = await storage.updateConfig(configData);
      
      // Don't expose sensitive data in response
      res.json({
        ...config,
        whatsappAccessToken: config.whatsappAccessToken ? "***" : ""
      });
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Validation error", errors: error.errors });
      } else {
        res.status(500).json({ message: error.message });
      }
    }
  });

  // System status
  app.get("/api/status", async (req, res) => {
    try {
      const config = await storage.getConfig();
      const status = {
        hubspotWebhook: "active",
        whatsappApi: config?.whatsappAccessToken ? "connected" : "disconnected",
        rateLimits: "78% used",
        messageQueue: "clear"
      };
      
      res.json(status);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
