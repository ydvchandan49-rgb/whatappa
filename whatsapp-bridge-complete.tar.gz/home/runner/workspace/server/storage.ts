import { 
  type FormSubmission, 
  type InsertFormSubmission,
  type WhatsappMessage,
  type InsertMessage,
  type MessageTemplate,
  type InsertTemplate,
  type SystemConfig,
  type InsertConfig
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Form Submissions
  createFormSubmission(submission: InsertFormSubmission): Promise<FormSubmission>;
  getFormSubmission(id: string): Promise<FormSubmission | undefined>;
  getFormSubmissionByHubspotId(hubspotId: string): Promise<FormSubmission | undefined>;
  updateFormSubmissionStatus(id: string, status: string, processedAt?: Date): Promise<FormSubmission | undefined>;
  getRecentFormSubmissions(limit?: number): Promise<FormSubmission[]>;
  getDashboardMetrics(): Promise<{
    todaySubmissions: number;
    messagesSent: number;
    failedMessages: number;
    avgProcessingTime: string;
  }>;

  // WhatsApp Messages
  createMessage(message: InsertMessage): Promise<WhatsappMessage>;
  getMessage(id: string): Promise<WhatsappMessage | undefined>;
  updateMessageStatus(id: string, status: string, whatsappMessageId?: string, errorMessage?: string): Promise<WhatsappMessage | undefined>;
  getMessagesBySubmission(submissionId: string): Promise<WhatsappMessage[]>;
  getRecentMessages(limit?: number): Promise<WhatsappMessage[]>;

  // Message Templates
  createTemplate(template: InsertTemplate): Promise<MessageTemplate>;
  getTemplate(id: string): Promise<MessageTemplate | undefined>;
  getActiveTemplate(): Promise<MessageTemplate | undefined>;
  getAllTemplates(): Promise<MessageTemplate[]>;
  updateTemplate(id: string, updates: Partial<InsertTemplate>): Promise<MessageTemplate | undefined>;
  deleteTemplate(id: string): Promise<boolean>;

  // System Configuration
  getConfig(): Promise<SystemConfig | undefined>;
  updateConfig(config: InsertConfig): Promise<SystemConfig>;
}

export class MemStorage implements IStorage {
  private formSubmissions: Map<string, FormSubmission>;
  private messages: Map<string, WhatsappMessage>;
  private templates: Map<string, MessageTemplate>;
  private config: SystemConfig | undefined;

  constructor() {
    this.formSubmissions = new Map();
    this.messages = new Map();
    this.templates = new Map();
    this.config = undefined;

    // Initialize with a default template
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    const defaultTemplate: MessageTemplate = {
      id: randomUUID(),
      name: "Default Welcome",
      content: "Hi {{contactName}}! Thanks for your interest. We received your {{formName}} submission and will get back to you soon!",
      isActive: true,
      variables: ["contactName", "formName"],
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.templates.set(defaultTemplate.id, defaultTemplate);
  }

  async createFormSubmission(insertSubmission: InsertFormSubmission): Promise<FormSubmission> {
    const id = randomUUID();
    const submission: FormSubmission = {
      ...insertSubmission,
      id,
      status: insertSubmission.status || "pending",
      createdAt: new Date(),
      processedAt: null,
    };
    this.formSubmissions.set(id, submission);
    return submission;
  }

  async getFormSubmission(id: string): Promise<FormSubmission | undefined> {
    return this.formSubmissions.get(id);
  }

  async getFormSubmissionByHubspotId(hubspotId: string): Promise<FormSubmission | undefined> {
    return Array.from(this.formSubmissions.values()).find(
      (submission) => submission.hubspotSubmissionId === hubspotId
    );
  }

  async updateFormSubmissionStatus(id: string, status: string, processedAt?: Date): Promise<FormSubmission | undefined> {
    const submission = this.formSubmissions.get(id);
    if (submission) {
      submission.status = status;
      submission.processedAt = processedAt || new Date();
      this.formSubmissions.set(id, submission);
    }
    return submission;
  }

  async getRecentFormSubmissions(limit = 10): Promise<FormSubmission[]> {
    return Array.from(this.formSubmissions.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  async getDashboardMetrics(): Promise<{
    todaySubmissions: number;
    messagesSent: number;
    failedMessages: number;
    avgProcessingTime: string;
  }> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const todaySubmissions = Array.from(this.formSubmissions.values())
      .filter(s => s.createdAt >= today).length;

    const sentMessages = Array.from(this.messages.values())
      .filter(m => m.status === 'sent' || m.status === 'delivered').length;

    const failedMessages = Array.from(this.messages.values())
      .filter(m => m.status === 'failed').length;

    return {
      todaySubmissions,
      messagesSent: sentMessages,
      failedMessages,
      avgProcessingTime: "1.2s"
    };
  }

  async createMessage(insertMessage: InsertMessage): Promise<WhatsappMessage> {
    const id = randomUUID();
    const message: WhatsappMessage = {
      ...insertMessage,
      id,
      status: insertMessage.status || "pending",
      templateId: insertMessage.templateId || null,
      whatsappMessageId: null,
      errorMessage: null,
      sentAt: null,
      deliveredAt: null,
      createdAt: new Date(),
    };
    this.messages.set(id, message);
    return message;
  }

  async getMessage(id: string): Promise<WhatsappMessage | undefined> {
    return this.messages.get(id);
  }

  async updateMessageStatus(id: string, status: string, whatsappMessageId?: string, errorMessage?: string): Promise<WhatsappMessage | undefined> {
    const message = this.messages.get(id);
    if (message) {
      message.status = status;
      if (whatsappMessageId) message.whatsappMessageId = whatsappMessageId;
      if (errorMessage) message.errorMessage = errorMessage;
      if (status === 'sent') message.sentAt = new Date();
      if (status === 'delivered') message.deliveredAt = new Date();
      this.messages.set(id, message);
    }
    return message;
  }

  async getMessagesBySubmission(submissionId: string): Promise<WhatsappMessage[]> {
    return Array.from(this.messages.values())
      .filter(message => message.submissionId === submissionId);
  }

  async getRecentMessages(limit = 10): Promise<WhatsappMessage[]> {
    return Array.from(this.messages.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  async createTemplate(insertTemplate: InsertTemplate): Promise<MessageTemplate> {
    const id = randomUUID();
    const template: MessageTemplate = {
      ...insertTemplate,
      id,
      isActive: insertTemplate.isActive || false,
      variables: insertTemplate.variables || [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    
    // If this template is set as active, deactivate others
    if (template.isActive) {
      for (const existingTemplate of Array.from(this.templates.values())) {
        existingTemplate.isActive = false;
      }
    }
    
    this.templates.set(id, template);
    return template;
  }

  async getTemplate(id: string): Promise<MessageTemplate | undefined> {
    return this.templates.get(id);
  }

  async getActiveTemplate(): Promise<MessageTemplate | undefined> {
    return Array.from(this.templates.values()).find(template => template.isActive);
  }

  async getAllTemplates(): Promise<MessageTemplate[]> {
    return Array.from(this.templates.values())
      .sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime());
  }

  async updateTemplate(id: string, updates: Partial<InsertTemplate>): Promise<MessageTemplate | undefined> {
    const template = this.templates.get(id);
    if (template) {
      Object.assign(template, updates, { updatedAt: new Date() });
      
      // If this template is set as active, deactivate others
      if (updates.isActive) {
        for (const [otherId, otherTemplate] of Array.from(this.templates.entries())) {
          if (otherId !== id) {
            otherTemplate.isActive = false;
          }
        }
      }
      
      this.templates.set(id, template);
    }
    return template;
  }

  async deleteTemplate(id: string): Promise<boolean> {
    return this.templates.delete(id);
  }

  async getConfig(): Promise<SystemConfig | undefined> {
    return this.config;
  }

  async updateConfig(insertConfig: InsertConfig): Promise<SystemConfig> {
    const config: SystemConfig = {
      id: this.config?.id || randomUUID(),
      whatsappApiEndpoint: insertConfig.whatsappApiEndpoint || null,
      whatsappAccessToken: insertConfig.whatsappAccessToken || null,
      whatsappPhoneNumberId: insertConfig.whatsappPhoneNumberId || null,
      hubspotWebhookSecret: insertConfig.hubspotWebhookSecret || null,
      enableLogging: insertConfig.enableLogging !== undefined ? insertConfig.enableLogging : true,
      updatedAt: new Date(),
    };
    this.config = config;
    return config;
  }
}

export const storage = new MemStorage();
